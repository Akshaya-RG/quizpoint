<?php
session_start();
include 'db.php';
$uno=$_SESSION['uname'];
if($uno=='')
 {

         echo '<script>alert("Please sign up");</script>';
        echo '<script>window.location= "frontpage.php"</script>';
 
  }
$query="select * from user where un like '$uno'";
$y=mysqli_query($db,$query);
 while( $r = mysqli_fetch_assoc($y))
 {
  $fn=$r['fn'];
  if($fn==NULL)
{
  echo "<script>window.location.href='register.php';</script>";
}
$t=$r['t_ins'];
$s=$r['pic'];
$n=$r['un'];
$m=$r['fn']." ".$r['ln'];
$gen=$r['gender'];

if($t=='clg')
{
 
  $ins=$r['ins'];
  $yr=$r['yr'];
  $dept=$r['dept'];
  
}


else
{
  $ins=$r['ins'];
  $yr=$r['class'];
  $dept=$r['gp'];
  
}
} 

$_SESSION['t_ins']=$t;
$_SESSION['yr']=$yr;
$_SESSION['dept']=$dept;
$_SESSION['ins']=$ins;

