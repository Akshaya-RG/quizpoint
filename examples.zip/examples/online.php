<html>
<head>
<script type="text/javascript">
  $(document).ready(function()
{
    $(window).bind("beforeunload", function() { 
       
        <?php
             mysqli_query($db,"update user set online='offline' where un like 185108");
        ?>
         return confirm("Do you really want to close?"); 

    });
});
</script>
</head>
</html>