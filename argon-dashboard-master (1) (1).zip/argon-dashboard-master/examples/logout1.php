<?php
session_start(); 
error_reporting(E_ERROR | E_WARNING | E_PARSE);
$un=$_SESSION['uname'];
include 'db.php';   
 mysqli_query($db,"update user set online='offline' where un like '$un';");
     echo "<script>window.location.href='frontpage.php';</script>";
	session_destroy();
?>  