<?php

include 'db.php';
$n=$_POST["button"];
mysqli_query($db,"use quiz2m");
$h=mysqli_query($db,"delete from q_user where un='$n';");
if($h)
{
  echo "<script type= 'text/javascript'>alert('Deleted Successfully')</script>";
  echo '<script>window.location= "user.php"</script>';
}
else
{
    $k=mysqli_error($db);
	echo "$k";
}

?>

