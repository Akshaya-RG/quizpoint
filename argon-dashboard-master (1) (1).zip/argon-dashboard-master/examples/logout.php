<?php
session_start(); 

    echo "<script>window.location.href='frontpage.php';</script>";
	session_destroy();
?>