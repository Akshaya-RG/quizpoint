<?php

include 'db.php';  
               $a=$_POST['submit'];
                $myfile=$_FILES['myfile']['name'];
                $extension = pathinfo($_FILES["myfile"]["name"], PATHINFO_EXTENSION);
                $target = "answerkeys/" .basename($a.'.'.$extension);
               
                $sql = "UPDATE post_ans SET status='$a.$extension' WHERE ass_no='$a';";
                if(mysqli_query($db,$sql))
                {
                  echo "";
                }
                else{
                  echo "Error: "  . mysqli_error($db);
                }
                if(move_uploaded_file($_FILES['myfile']['tmp_name'],$target))
                {
                    echo"";
                }
  
header("Location: comp_ass.php");
?>