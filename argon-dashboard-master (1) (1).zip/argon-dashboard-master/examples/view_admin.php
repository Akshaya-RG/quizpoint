<?php
session_start();
include 'db.php';
include 'adb.php';
$k=$_SESSION['k'];
if($admin==NULL && $stss!='Superadmin')
{
   echo '<script>alert("Sry u are blocked to this page");</script>';
        echo '<script>window.location= "dashboard.php"</script>';
}
 $_SESSION["stss"]=$stss;
$qqq="select max(created_on) as m from admin";
$t=mysqli_query($db,$qqq);
while ($r=mysqli_fetch_assoc($t)) {
  $st=$r['m'];
}
date_default_timezone_set('Asia/Kolkata');
$ttt=date('Y-m-d H:i:s');
?>


<!DOCTYPE html>
<html>

<head>
<style type="text/css">
  input[type=text],input[type=email],input[type=number],input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

/* Set a style for all buttons */
button {
  background-color:#5e72e4;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

/* Center the image and position the close button */



.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}
.modala {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}
/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
  position: absolute;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}

/* Add Zoom Animation */
.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
     
  }
}
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color:#FFFFFF ;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 100px;
}
.sidenav a, .dropdown-btn {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
  border: none;
  background: none;
  width:100%;
  text-align: left;
  cursor: pointer;
  outline: none;
}

/* Dropdown container (hidden by default). Optional: add a lighter background color and some left padding to change the design of the dropdown content */
.dropdown-container {
  display: none;
  background-color: #FFFFFF;
  padding-left: 8px;
}

/* Optional: Style the caret down icon */
.fa-caret-down {
  float: right;
  padding-right: 8px;
}


.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 17px;
  color: #111;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #6A5ACD;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 100px;
  
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
body  {
  background-color: #fff;
}
  </style>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>Quiz Point</title>
  <!-- Favicon -->
  <link rel="icon" href="../assets/img/brand/favicon.png" type="image/png">
  <!-- Fonts -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
  <!-- Icons -->
  <link rel="stylesheet" href="../assets/vendor/nucleo/css/nucleo.css" type="text/css">
  <link rel="stylesheet" href="../assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" type="text/css">
  <!-- Page plugins -->
  <!-- Argon CSS -->
  <link rel="stylesheet" href="../assets/css/argon.css?v=1.2.0" type="text/css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body >
  
  <!-- Main content -->
  <div class="main-content" id="panel">
    <!-- Topnav -->
    <nav class="navbar navbar-top navbar-expand navbar-dark  border-bottom" style="background-color:black">
      <div class="container-fluid">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <!-- Search form -->
          
      <div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()" >&times;</a>
  
  <a class="nav-link active" href="dashboard.php">
                <i class="ni ni-tv-2 text-primary"></i>
                <span class="nav-link-text">Dashboard</span>
              </a><br>
              <a class="nav-link " href="view_admin.php">
                <i class="ni ni-single-02 text-red"></i>
                <span class="nav-link-text">View Admin</span>
              </a><br>
              <a class="nav-link" href="user.php">
                <i class="ni ni-circle-08 text-primary"></i>
                <span class="nav-link-text">View user</span>
              </a><br>
              <a class="nav-link " href="sche_ass.php">
                <i class="ni ni-single-copy-04 text-green"></i>
                <span class="nav-link-text">View Scheduled Assessments</span>
              </a><br>
              <a class="nav-link" href="comp_ass.php">
                <i class="ni ni-book-bookmark "></i>
                <span class="nav-link-text">View Completed Assessments</span>
              </a> <br>
         <?php
              if($stss=='Superadmin')
              {
                echo'
         <a class="dropdown-btn">
          <i class="fa fa-trash-o" style="font-size:25px"></i>
                    <span class="nav-link-text">DELETED</span>
          
          </a>
          
          
          <div class="dropdown-container">
          <a class="nav-link" href="deluser.php">
                    <i class="ni ni-basket"></i>
                     <span class="nav-link-text">User</span>
                       </a>
           <a class="nav-link" href="del_admin.php">
                    <i class="ni ni-basket"></i>
                     <span class="nav-link-text">Admin</span>
                       </a>
                      
                               
          
          </div>
                </a>';
              }
                ?>
</div>
<span style="font-size:30px;color: #FFFFFF;cursor:pointer" onclick="openNav()" >&#9776; </span>
          <!-- Navbar links -->
          <ul class="navbar-nav align-items-center  ml-md-auto ">
            <li class="nav-item d-xl-none">
              <!-- Sidenav toggler -->
              
                
            </li>
           
            
          </ul>
         
 <ul class="navbar-nav align-items-center  ml-auto ml-md-0 ">
             <li>
              <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <div class="media align-items-center">
                  <div class="media-body  ml-2  d-none d-lg-block">
                    <span class="mb-0 text-sm  font-weight-bold"><i class="ni ni-single-02"></i>
                  <span>My profile</span></span>
                  </div>
                </div>
              </a>
              <div class="dropdown-menu  dropdown-menu-right ">
                <div class="dropdown-header noti-title">
                  <h6 class="text-overflow m-0">Welcome!</h6>
                </div>
                <a href="profile.php" class="dropdown-item">
                  <div class="media align-items-center">
                  <span class="avatar avatar-sm rounded-circle">
                    <?php
                      if($s == '')
                      {
                          echo '<img alt="Image placeholder" src="../examples/images/male.png">';
                      }
                      else{
                          echo '<img alt="Image placeholder" src="../examples/images/<?php echo $s; ?>">';
                      }
                      ?>
                  </span>
                  <div class="media-body  ml-2  d-none d-lg-block">
                    <span class="mb-0 text-sm  font-weight-bold"><?php echo $b; ?></span>
                  </div>
                </div>
                </a>
                <a href="#!" class="dropdown-item">
                  <i class="ni ni-badge"></i>
                  <span><?php echo $a; ?></span>
                </a>
                <a href="admin_cpass.php" class="dropdown-item">
                  <i class="ni ni-settings-gear-65"></i>
                  <span>Change Password</span>
                </a>
                <a href="#!" class="dropdown-item">
                  <span class="badge badge-dot mr-4">
                       <i class="bg-success"  style=""></i>
                       <span class="status">&nbsp &nbsp status</span>
                     </span>
               </a>
                <div class="dropdown-divider"></div>
                <a href="logout.php" class="dropdown-item">
                  <i class="ni ni-user-run"></i>
                  <span>Logout</span>
                </a>
              </div>
            </li>
            
          </ul>
        </div>
      </div>
    </nav>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "750px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}

var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}
</script>

    <!-- Header -->
    <!-- Header -->
    <div class="header bg-primary pb-6" style="background-image:url(images/bimage.jpeg);background-size: cover";>
      <div class="container-fluid">
        <div class="header-body">
         <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">
              <?php
              if($stss=='Superadmin')
                echo 'Super Admin';
              else
                echo'Admin';
              ?></h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">View Admin</a></li>
                  
                </ol>
              </nav>
            </div>
            
          </div>
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--4">
      <div class="row justify-content-center">
        <div class=" col ">
          <div class="card">
          <div class="card-header border-0">
              <h2 class="mb-0">Admins Employed</h2>
			</div>  
         <div class="row">
              <div class="col-8">
               <form class="navbar-search navbar-search-light form-inline mr-sm-3" id="navbar-search-main">
            <div class="form-group mb-0">
              <div class="input-group input-group-alternative input-group-merge">
                <div class="input-group-prepend">
                  <span class="input-group-text"><i class="fas fa-search"></i></span>
                </div>
                <input class="form-control" id="search" placeholder="Search" onkeyup="showUser(this.value)" type="text"><br><br>
              </div>
            </div>
          </form>
		  </div>
     
 <div class="col-4">                 
  
         
                  <?php
              if($stss=='Superadmin' || $user1[0]=='add')
              {
                ?>
<button onclick="document.getElementById('id01').style.display='block'" class="btn btn-primary btn-lg" style="width:250px;">Add Admin</button>
<?php
}
?>


 
</div>
</div>
  <div class="col-12" style="padding-top:20px;">
  <div id="txtHint"><b></b></div> 
</div>


<div id="id01" class="modala">
<div class="modal-dialog ">


  <form class="modal-content animate" >
  
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      
    </div>

    <div class="container">
      
      
      <label for="uname"><b>Email</b></label><br>
      <input type="text"  id="email"  placeholder="Enter Email" name="email" autocomplete="off" required><br>
                        <h5 id="emcheck"> </h5>
  <hr>          
     <label for="uname"><b>ACCESSIBILITY OF ADMIN</b></label>
       <div class="col-lg-9" >
      USERPAGE :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     <input type="checkbox" name="pri[]" onchange="showhide(this.checked)" value='user' id="pri" > <label ><b>view user</b></label><br>
     </div>
     <div id="hiddenField" style="display:none">
     <input type="checkbox" name="us" id="us" value='add'> <label >ADD</label>&nbsp;&nbsp;
     <input type="checkbox" name="us" id="us" value='remove'> <label >REMOVE</label>&nbsp;&nbsp;
     
    </div>
       <div class="col-lg-9" style="padding-left:39px">
      ADMINPAGE:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     <input type="checkbox" name="pri[]" onchange="showhide1(this.checked)" value='admin' id="pri"> <label ><b>view admin</b></label><br>
      </div>   
     
    <div class="col-lg-15">
     SCH_ASS PAGE :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <input type="checkbox" name="pri[]" onchange="showhide2(this.checked)" value='scheass' id="pri"> <label ><b>view scheduled assessments</b></label>
     </div>       
     <div id="hiddenField2" style="display:none">
     <input type="checkbox" name="sa" id="sa" value='add' > <label >ADD</label>&nbsp;&nbsp;
     <input type="checkbox" name="sa" id="sa" value='remove'> <label >REMOVE</label>&nbsp;&nbsp;
     <input type="checkbox" name="sa" id="sa" value='edit'> <label >EDIT</label>
      <br>
     </div>
     <div class="col-lg-15">
      COMP_ASS PAGE :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     <input type="checkbox" name="pri[]" onchange="showhide3(this.checked)" value='compass' id="pri"> <label ><b>view completed assessments</b></label><br>
        </div>     
     <div id="hiddenField3" style="display:none">
     <input type="checkbox" name="ca" id="ca" value='indrank' > <label >Individual ranking</label>&nbsp;&nbsp;
     <input type="checkbox" name="ca" id="ca" value='rank'> <label >Ranking</label>&nbsp;&nbsp;
     <input type="checkbox" name="ca" id="ca" value='upload'> <label >Upload</label>     
   </div>
    </div>
   
     <div class="modal-footer">   
      <button type="submit" id='next'  style="width: 50%"  onclick="addadmin()">Add</button>
     </div>
    

    
  </form>

</div>
</div>

<h4 id="del" class="text-danger"></h4>
<h3 id="success" class="text-success"></h3>
<script type="text/javascript">
  function addins()
{
  $("h3").text(" Inserted Successfully");
              setTimeout(function(){  

  
$('#success').fadeOut("Slow"); 
}, 3000);
            }
</script>
<?php
$now = new DateTime($ttt);
$ref = new DateTime($st);
$f= $now->diff($ref);
if($f->d==0 && $f->h==0 && $f->m==0 && $f->s<10)
{
  
  ?>
  
 <script type="text/javascript">
 addins();
</script>
 <?php
  

}
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
function showhide(checked)
{
  if(checked === true)
  {
    $("#hiddenField").fadeIn();
  }
  else
    {$("#hiddenField").fadeOut();

 }
}
function showhide1(checked)
{
  if(checked === true)
  {
    $("#hiddenField1").fadeIn();
  }
  else
    $("#hiddenField1").fadeOut();
}
function showhide2(checked)
{
  if(checked === true)
  {
    $("#hiddenField2").fadeIn();
  }
  else
    $("#hiddenField2").fadeOut();
}
function showhide3(checked)
{
  if(checked === true)
  {
    $("#hiddenField3").fadeIn();
  }
  else
    $("#hiddenField3").fadeOut();
}


</script>

<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">

  $('#email').keyup(function(){
                emchk();
                      
        });

                


           function emchk(){
          valid = true;
          var email = $('#email').val();
          var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;  
            
            if(email.length == ''){
              $('#emcheck').show();
              $('#emcheck').html("**please fill your emailid");
              $('#emcheck').focus();
              $('#emcheck').css("color","red");
              valid = false;
              
              
              
              
            }
            else if(!regex.test(email)){
              $('#emcheck').show();
              $('#emcheck').html("**invalid emailid");
              $('#emcheck').focus();
              $('#emcheck').css("color","red");
             valid = false;
             
            }
            
            
            
            
            else{
            $('#emcheck').hide();
            valid= true;
           }
                         
                        
            return valid;                
          }
              

function addadmin(){
  var valid; 
   var email = $('#email').val();
   var ids=[]; 
$('#pri:checked').each(function(){
    ids.push($(this).val());
});
var ii = ids.toString();
var ids1=[]; 
$('#us:checked').each(function(){
    ids1.push($(this).val());
});
var ii1 = ids1.toString();
var ids2=[]; 
$('#sa:checked').each(function(){
    ids2.push($(this).val());
});
var ii2 =  ids2.toString();
var ids3=[]; 
$('#ca:checked').each(function(){
    ids3.push($(this).val());
});
var ii3 = ids3.toString();
    valid = emchk();
    console.log(valid);
    if(valid) {
      
   $.ajax({
      url:"admincrud.php",
      type:'post',
      data: { 
          email : email,
          ii : ii,
          ii1 : ii1,
          ii2 : ii2,
          ii3 : ii3,
       },

       success:function(data){
       
       
       
        readrecords();

       }

   });
 }
 console.log(ids);
 console.log(ids1);
 console.log(ids2);
 console.log(ids3);
}



</script>

                    
                    
                    <div class="table-responsive" id="recorddisplay">
              
              
                    <?php
                    $i=1;
                    if(isset($_GET['page']))
                     {
                       $page=$_GET['page'];
                       $_SESSION["pg"] = $page;
                       
                      ?>
                      <div id="recorddisplay">

                      </div>

<?php
                     }
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $('#search').keyup(function(){
      var search = $('#search').val();
      if(search.length == ''){
    readrecords();
    }    
    else
    {
      $("#tab").hide(); 
      $("#nnnav").hide(); 
      
    }

        });
    
function showUser(str) {
  if (str=="") {
    document.getElementById("txtHint").innerHTML="";
    return;
  }
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("txtHint").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","admincrud.php?q="+str,true);
  xmlhttp.send();

  
}
</script>


<script type="text/javascript">

$(document).ready(function(){
    readrecords();
    
});



     function readrecords(){

$.ajax({
url:"admincrud.php",
type:'post',


success:function(response){
$('#recorddisplay').html(response);
}
});
}

 
$(document).on('click','.update',function(e) {
    var id=$(this).attr("data-id");
    var aid=$(this).attr("data-aid");
    var name=$(this).attr("data-name");
    var email=$(this).attr("data-email");
    var desig=$(this).attr("data-desig");
    var quali=$(this).attr("data-quali");
    var ins=$(this).attr("data-ins");
    var phno=$(this).attr("data-phno");
    
    var ad=$(this).attr("data-admin1");
    var uss=$(this).attr("data-user1");
    var sas=$(this).attr("data-sche1");
    var cas=$(this).attr("data-comp1");
    
    $('#id_u').val(id);
    $('#aid_u').val(aid);
    $('#name_u').val(name);
    $('#email_u').val(email);
    $('#desig_u').val(desig);
    $('#quali_u').val(quali);
    $('#ins_u').val(ins);
    $('#phno_u').val(phno);

    $('#id_v').val(id);
    $('#aid_v').val(aid);
    $('#name_v').val(name);
    $('#email_v').val(email);
    $('#desig_v').val(desig);
    $('#quali_v').val(quali);
    $('#ins_v').val(ins);
    $('#phno_v').val(phno);

    $('#id_b').val(id);
    $('#id_a').val(id);
    $('#user1').val(uss);
    $('#admin1').val(ad);
    $('#sche1').val(sas);
    $('#comp1').val(cas);

  });


function editass(ass1)
{ 
  var idb=$('#id_b').val();
  
   var idsu=[]; 
$('#pri1:checked').each(function(){
    idsu.push($(this).val());
});
var iiu = idsu.toString();
var idsu1=[]; 
$('#us1:checked').each(function(){
    idsu1.push($(this).val());
});
var iiu1 = idsu1.toString();
var idsu2=[]; 
$('#sa1:checked').each(function(){
    idsu2.push($(this).val());
});
var iiu2 =  idsu2.toString();
var idsu3=[]; 
$('#ca1:checked').each(function(){
    idsu3.push($(this).val());
});
var iiu3 = idsu3.toString();
  
 
   $.ajax({
      url:"admincrud.php",
      type:'post',
      data: { 
         ass1 : ass1,
          idb : idb,
          iiu : iiu,
          iiu1 : iiu1,
          iiu2 : iiu2,
          iiu3 : iiu3,
       },

       success:function(data){
       
       
       
        readrecords();

       }

   });
 
 console.log(idsu);
 console.log(idsu1);
 console.log(idsu2);
 console.log(idsu3);
}
function updateqns(ass){
   
   var aid_u=$('#aid_u').val();
   var name_u = $('#name_u').val();
   var desig_u = $('#desig_u').val();
   var quali_u = $('#quali_u').val();
   var ins_u = $('#ins_u').val();
   var phno_u = $('#phno_u').val();
   var valid1;
   var valid2;
   var valid3;
   valid1=firstchk();
   valid2=lastchk();
   valid3=phonenochk();
   console.log(valid1);
   console.log(valid2);
   console.log(valid3);
   if(valid1 && valid2 && valid3)
   {
   $.ajax({
      url:"admincrud.php",
      type:'post',
      data: { 
          
          ass : ass,
          aid_u:aid_u,
          name_u : name_u,
          desig_u : desig_u,
          quali_u : quali_u,
          ins_u : ins_u,
          phno_u : phno_u,

          
       },

       success:function(data,status){

       }


   });
 }
   
}




</script>

<script type="text/javascript">







      function deleteadmin(deleteid){
        var conf = confirm("Are You Sure.You want to delete the Admin.");
        if(conf==true){
          $.ajax({
            url:"admincrud.php",
            type:"post",
            data:{ deleteid:deleteid },
            success:function(data,status){
             
              $("h4").text(" Deleted Successfully");
              setTimeout(function(){  

  
$('#del').fadeOut("Slow");  


}, 3000);
readrecords();
            }

          });
        }
      }

      function unblock(ubid){
        
       
          $.ajax({
            url:"admincrud.php",
            type:"post",
            data:{ ubid:ubid },
            success:function(data,status){
              readrecords();

            }

          });
        
      }


      
      function block(bid){
        
       
        $.ajax({
          url:"admincrud.php",
          type:"post",
          data:{ bid:bid },
          success:function(data,status){
            readrecords();

          }

        });
      
    }


   </script>






            </div>

                
          </div>
        </div>
      </footer>
    </div>
  </div>
  <!-- Argon Scripts -->
  <!-- Core -->
  <script src="../assets/vendor/jquery/dist/jquery.min.js"></script>
  <script src="../assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/js-cookie/js.cookie.js"></script>
  <script src="../assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
  <script src="../assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
  <!-- Optional JS -->
  <script src="../assets/vendor/clipboard/dist/clipboard.min.js"></script>
  <!-- Argon JS -->
  <script src="../assets/js/argon.js?v=1.2.0"></script>
</body>
</html>
