<?php
session_start();
include 'db.php';
$k=$_SESSION['k'];
$an=$_SESSION['ano'];
$query="select * from admin where an like '$an'";
  $y=mysqli_query($db,$query);
 while( $r = mysqli_fetch_assoc($y))
 {$a=$r['an'];
  $b=$r['name'];
  $s=$r['pic'];
  $stss=$r['status'];
 }
if(isset($_POST['but1']))
{
  $l=$_POST['but1'];
$_SESSION['l']=$l;
}
else
{
  $l=$_SESSION['l'];
}
?>
<html>

<head>
  <style type="text/css">
  .button1 {border-radius: 12px;}

  button {
  background-color: #5e72e4;
  color: white;
  border-radius:12px;
  padding: 14px 14px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.7;
}

input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */

  padding-left:500px;
  padding-right:400px;
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}


body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color:#FFFFFF ;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 100px;
}
.sidenav a, .dropdown-btn {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 20px;
  color: #818181;
  display: block;
  border: none;
  background: none;
  width:100%;
  text-align: left;
  cursor: pointer;
  outline: none;
}

/* Dropdown container (hidden by default). Optional: add a lighter background color and some left padding to change the design of the dropdown content */
.dropdown-container {
  display: none;
  background-color: #FFFFFF;
  padding-left: 8px;
}

/* Optional: Style the caret down icon */
.fa-caret-down {
  float: right;
  padding-right: 8px;
}


.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 17px;
  color: #111;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #6A5ACD;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 100px;
  
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
body  {
  background-color: #fff;
 
}
  </style>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>Quiz</title>
  <!-- Favicon -->
  <link rel="icon" href="../assets/img/brand/favicon.png" type="image/png">
  <!-- Fonts -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
  <!-- Icons -->
  <link rel="stylesheet" href="../assets/vendor/nucleo/css/nucleo.css" type="text/css">
  <link rel="stylesheet" href="../assets/vendor/@fortawesome/fontawesome-free/css/all.min.css" type="text/css">
  <!-- Page plugins -->
  <!-- Argon CSS -->
  <link rel="stylesheet" href="../assets/css/argon.css?v=1.2.0" type="text/css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
  

  <!-- Main content -->
  <div class="main-content" id="panel">
    <!-- Topnav -->
    <nav class="navbar navbar-top navbar-expand navbar-dark  border-bottom" style="background-color:black">
      <div class="container-fluid">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <!-- Search form -->
          
      <div id="mySidenav" class="sidenav">
      <a href="javascript:void(0)" class="closebtn" onclick="closeNav()" >&times;</a>
  
  <a class="nav-link active" href="dashboard.php">
                <i class="ni ni-tv-2 text-primary"></i>
                <span class="nav-link-text">Dashboard</span>
              </a><br>
              <a class="nav-link " href="view_admin.php">
                <i class="ni ni-single-02 text-red"></i>
                <span class="nav-link-text">View Admin</span>
              </a><br>
              <a class="nav-link" href="user.php">
                <i class="ni ni-circle-08 text-primary"></i>
                <span class="nav-link-text">View user</span>
              </a><br>
              <a class="nav-link " href="sche_ass.php">
                <i class="ni ni-single-copy-04 text-green"></i>
                <span class="nav-link-text">View Scheduled Assessments</span>
              </a><br>
              <a class="nav-link" href="comp_ass.php">
                <i class="ni ni-book-bookmark "></i>
                <span class="nav-link-text">View Completed Assessments</span>
              </a> <br>
         <?php
              if($stss=='Superadmin')
              {
                echo'
         <a class="dropdown-btn">
          <i class="fa fa-trash-o" style="font-size:25px"></i>
                    <span class="nav-link-text">DELETED</span>
          
          </a>
          
          
          <div class="dropdown-container">
          <a class="nav-link" href="deluser.php">
                    <i class="ni ni-basket"></i>
                     <span class="nav-link-text">User</span>
                       </a>
           <a class="nav-link" href="del_admin.php">
                    <i class="ni ni-basket"></i>
                     <span class="nav-link-text">Admin</span>
                       </a>
                      
                               
          
          </div>
                </a>';
              }
                ?>
</div>
<span style="font-size:30px;color: #FFFFFF;cursor:pointer" onclick="openNav()" >&#9776; </span>
          <!-- Navbar links -->
          <ul class="navbar-nav align-items-center  ml-md-auto ">
            <li class="nav-item d-xl-none">
              <!-- Sidenav toggler -->
              
                
            </li>
           
            
          </ul>
         
        <ul class="navbar-nav align-items-center  ml-auto ml-md-0 ">
             <li>
              <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <div class="media align-items-center">
                  <div class="media-body  ml-2  d-none d-lg-block">
                    <span class="mb-0 text-sm  font-weight-bold"><i class="ni ni-single-02"></i>
                  <span>My profile</span></span>
                  </div>
                </div>
              </a>
              <div class="dropdown-menu  dropdown-menu-right ">
                <div class="dropdown-header noti-title">
                  <h6 class="text-overflow m-0">Welcome!</h6>
                </div>
                <a href="profile.php" class="dropdown-item">
                  <div class="media align-items-center">
                  <span class="avatar avatar-sm rounded-circle">
                     <?php
                      if($s == '')
                      {
                          echo '<img alt="Image placeholder" src="../examples/images/male.png">';
                      }
                      else{
                          echo '<img alt="Image placeholder" src="../examples/images/<?php echo $s; ?>">';
                      }
                      ?>
                  </span>
                  <div class="media-body  ml-2  d-none d-lg-block">
                    <span class="mb-0 text-sm  font-weight-bold"><?php echo $b; ?></span>
                  </div>
                </div>
                </a>
                <a href="#!" class="dropdown-item">
                  <i class="ni ni-badge"></i>
                  <span><?php echo $a; ?></span>
                </a>
                <a href="admin_cpass.php" class="dropdown-item">
                  <i class="ni ni-settings-gear-65"></i>
                  <span>Change Password</span>
                </a>
                <a href="#!" class="dropdown-item">
                  <span class="badge badge-dot mr-4">
                       <i class="bg-success"  style=""></i>
                       <span class="status">&nbsp &nbsp status</span>
                     </span>
               </a>
                <div class="dropdown-divider"></div>
                <a href="logout.php" class="dropdown-item">
                  <i class="ni ni-user-run"></i>
                  <span>Logout</span>
                </a>
              </div>
            </li>
            
          </ul>
        </div>
      </div>
    </nav>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript"></script>
<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "750px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}

/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}
</script>



    <!-- Header -->
    <!-- Header -->
    <div class="header bg-primary pb-6" style="background-image:url(images/bimage.jpeg);background-size: cover";>
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Super Admin</h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">View Admin</a></li>
                  
                </ol>
              </nav>
            </div>
            
          </div>
          <!-- Card stats -->
          
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
   <div class="row">
        <div class="col">
          <div class="card">
            <!-- Card header -->
            <div class="card-header border-0">
              <?php
                $date=date('d/m/Y');
                     if($l=='all')
                     {echo'
                 <h2 class="mb-0">Overall Ranking</h2>
                 <h2 class="mb-0">As on date: '.$date.'</h2>';
                 }
                 else{
                     $query="select * from post_ans where ass_no ='$l';";
                     $y=mysqli_query($db,$query);
                     while( $r = mysqli_fetch_assoc($y))
                     {
                      $ass_name=$r['ass_name'];
                      $s_date=$r['s_date'];
                      $timestamp = strtotime($s_date);
                      $n_date = date("d/m/Y", $timestamp);
                     }
                     echo'
                 <h3 class="mb-0">Title of Assessment : '.$ass_name.'</h3><br>
                 <h3 class="mb-0">Date : '.$n_date.'</h3>';
               }
               ?>


            </div>
            <!-- Light table -->
            <div class="table-responsive">
              <form action="comp_ass.php" method="post">
              <table class="table align-items-center table-flush table-dark">
                <thead class="thead-dark">
                  <tr>
                    <th scope="col" class="sort" data-sort="name">S.no</th><th></th>
                    <th scope="col" class="sort" data-sort="budget">Name</th><th></th>
                    <th scope="col" class="sort" data-sort="status">Total Score</th><th></th>
                    <th scope="col" class="sort" data-sort="status">Rank</th>
                    <th scope="col">Batch</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody class="list">
                  <tr>
                    <?php
                    $i=1;
                    if(isset($_GET['page']))
                     {
                       $page=$_GET['page'];
                       if($page==1)
                       {
                        $_SESSION['jj']=0;
                        $k=1;
                       }
                       else
                       {
                        $k=(($page-1)*5)+1;
                       }
                       $page=mysqli_real_escape_string($db,$page);
                       $page=htmlentities($page);
                     }
                     else{
                       $page=1;
                     }
                    $n=1;
                    $j=$_SESSION['jj'];
                    $cnt=0;
                     
                     if($l=='all')
                     {
                      $query="select sum(marks_scored)/count(ass_no) as m,fn,ln,result.un from result inner join user on result.un=user.un group by result.un order by m desc";
                      $res=mysqli_query($db,$query);
                     $count=mysqli_num_rows($res);
                     $per_page=5;
                     $no_of_page=ceil($count/$per_page);
                     $start=($page-1)*$per_page;
                     $query="select sum(marks_scored)/count(ass_no) as m,fn,result.un,ln,batch from result inner join user on result.un=user.un group by result.un order by m desc limit $start,$per_page";
                      $y=mysqli_query($db,$query);
                     while( $r = mysqli_fetch_assoc($y))
                       {  while($n!=0)
                        {
                          $_SESSION['m']=$r['m'];
                          $n=0;
                          $cnt=0;
                        }
                         $uun=$r['un']; 

                          $un=$r['fn'].$r['ln'];
                          $mark=$r['m'];
                           $qq="select count(batch) as ll from result where batch like 'Gold' and un like '$uun' ";
                           $y1=mysqli_query($db,$qq);
                     while( $r1 = mysqli_fetch_assoc($y1))
                     {
                        $bc=$r1['ll'];
                     }
                          echo'
                          <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    <td></td>
                    <td class="budget">'
                      .$un.'
                    </td>
                    <td></td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$mark.'</span>
                      </span>
                    </td>
                    <td></td>
                    <td>';
                    if($_SESSION['m']==$mark){
                      if($cnt==0)
                      {
                        $j++;
                      }
                     echo'
                      <span class="status">'.$j.'</span>';
                      $n=0;
                      $cnt++;
                     
                    }
                    else
                    {
                      $n=1;
                       echo'
                      <span class="status">'.++$j.'</span>';
                      $_SESSION['jj']=$j;
                    }
                    echo'
                    </td>   
                    <td>
                  
                        <span class="avatar avatar-sm rounded-circle">
                    <img alt="Image placeholder" src="../examples/images/Gold.jpeg">
                  </span> &nbsp &nbsp-&nbsp &nbsp '.$bc.'
                         
                      
                    </td>
                     <td></td>';
                    echo "</tr>";
                  
                  
                }

                     }
                   else{
                     $query="select * from result inner join user on ass_no ='$l' and result.un=user.un order by marks_scored desc";
                     $res=mysqli_query($db,$query);
                     $count=mysqli_num_rows($res);
                     $per_page=5;
                     $no_of_page=ceil($count/$per_page);
                     $start=($page-1)*$per_page;
                     $query="select * from result inner join user on ass_no ='$l' and result.un=user.un order by marks_scored desc limit $start,$per_page";
                     $y=mysqli_query($db,$query);
                     while( $r = mysqli_fetch_assoc($y))
                       { while($n!=0)
                        {
                          $_SESSION['m']=$r['marks_scored'];
                          $n=0;
                        }  
                        $aa=$r['ass_no'];
                          $un=$r['fn'].$r['ln'];
                          $mark=$r['marks_scored'];
                           $bat=$r['batch'];                      
                        echo '
          
                    <td>
                      <div class="media align-items-center">
                        
                        <div class="media-body">
                          <span class="name mb-0 text-sm">'.$k++.'</span>
                        </div>
                      </div>
                    </td>
                    <td></td>
                    <td class="budget">'
                      .$un.'
                    </td>
                    <td></td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        
                        <span class="status">'.$mark.'</span>
                      </span>
                    </td>
                    <td></td>
                    <td>';
                       if($_SESSION['m']==$mark){
                         if($cnt==0)
                      {
                        $j++;
                      }
                     echo'
                      <span class="status">'.$j.'</span>';
                      $n=0;
                      $cnt++;
                    }
                    else
                    {
                      $n=1;
                       echo'
                      <span class="status">'.++$j.'</span>';
                      $_SESSION['jj']=$j;
                      
                    }
                    echo'
                    </td>   
                     </td>   
                    <td>
                     ';
                     if($bat=='none' or $bat==NULL){
                     echo 'NONE'; 
                  }
                  else
                  {
                    
                    echo'
                        <span class="avatar avatar-sm rounded-circle">
                     
                    <img alt="Image placeholder" src="../examples/images/'.$bat.'.jpeg">
                  </span> ';
                  }
                         
                   echo'   
                    </td>
                     <td></td>';
                    echo "</tr>";
                  
                  
                }
              }
                  ?>
                    
                 <tr>
                  <td></td>
                  <td></td>
                  <td></td>
                  
                  <td>
                   <button  class="button button1" style="vertical-align:middle"><span>Back</span></button>
                 </td>
                 <td></td>
                 <td></td>
                 <td></td>
                 <td></td>
                 </tr> 
                 
                </tbody>
              </table>
              <nav aria-label="Page navigation example">
  <ul class="pagination justify-content-end">
    <li 
    <?php
       if($page==1)
       {
         echo "class='page-item disabled'";
       }  
       else{
         echo "class='page-item'";
       }
    ?>
    >
      <a class="page-link" href="rank.php?page=<?php echo $page-1; ?>" tabindex="-1">
        <i class="fa fa-angle-left"></i>
      </a>
    </li>
    <?php
      for($i=1;$i<=$no_of_page;$i++)
      {
        ?>
           <li
            <?php 
              if($page==$i)
              {
              echo "class='page-item active'";
              }
              else{
                echo "class='page-item'";
              }

            ?>
           ><a class="page-link" href="rank.php?page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
        <?php
      }
    ?>
   
    <li 
    <?php
       if($page==$no_of_page)
       {
         echo "class='page-item disabled'";
       }  
       else{
         echo "class='page-item'";
       }
    ?>
    >
      <a class="page-link" href="rank.php?page=<?php echo $page+1; ?>">
        <i class="fa fa-angle-right"></i>
        
      </a>
    </li>
  </ul>
</nav>
            </form>
            </div>
            <!-- Card footer -->
            
          </div>
        </div>
      </div>
    </div>
  </div>

  
  <script src="../assets/vendor/jquery/dist/jquery.min.js"></script>
  <script src="../assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/js-cookie/js.cookie.js"></script>
  <script src="../assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
  <script src="../assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
  <!-- Optional JS -->
  <script src="../assets/vendor/chart.js/dist/Chart.min.js"></script>
  <script src="../assets/vendor/chart.js/dist/Chart.extension.js"></script>
  <!-- Argon JS -->
  <script src="../assets/js/argon.js?v=1.2.0"></script>
  
  
</body>

</html>